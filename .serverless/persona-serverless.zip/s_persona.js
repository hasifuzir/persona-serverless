var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'hasifuzir',
applicationName: 'persona-serverless',
appUid: '11vGwXkRGHdZ4WyS61',
tenantUid: 'sGNh0y9x7mYdJWwyVp',
deploymentUid: '0734b060-e87c-4c2f-bef9-2bebe645eaa4',
serviceName: 'persona-serverless',
stageName: 'dev',
pluginVersion: '3.2.7'})
const handlerWrapperArgs = { functionName: 'persona-serverless-dev-persona', timeout: 6}
try {
  const userHandler = require('./src/index.js')
  module.exports.handler = serverlessSDK.handler(userHandler.persona, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
