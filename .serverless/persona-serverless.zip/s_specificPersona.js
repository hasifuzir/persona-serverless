var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'hasifuzir',
applicationName: 'persona-serverless',
appUid: '11vGwXkRGHdZ4WyS61',
tenantUid: 'sGNh0y9x7mYdJWwyVp',
deploymentUid: 'fe11cc0a-26a2-4ac5-85fb-835d4bbc4372',
serviceName: 'persona-serverless',
stageName: 'dev',
pluginVersion: '3.2.7'})
const handlerWrapperArgs = { functionName: 'persona-serverless-dev-specificPersona', timeout: 6}
try {
  const userHandler = require('./src/index.js')
  module.exports.handler = serverlessSDK.handler(userHandler.specificPersona, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
