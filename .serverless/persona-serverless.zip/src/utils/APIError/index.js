const { APIError, generateError } = require('./APIError');

module.exports = {
  APIError,
  generateError
};
