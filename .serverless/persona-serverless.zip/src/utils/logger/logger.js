const { LambdaLog } = require('lambda-log');

const logger = new LambdaLog();

module.exports = logger;
