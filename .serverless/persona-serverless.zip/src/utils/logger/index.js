const logger = require('./logger');

module.exports = logger;
