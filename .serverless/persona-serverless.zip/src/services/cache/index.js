const cacheService = require('./cache.service');

module.exports = cacheService;
