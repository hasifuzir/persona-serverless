const dynamodbService = require('./dynamodb.service');

module.exports = dynamodbService;
