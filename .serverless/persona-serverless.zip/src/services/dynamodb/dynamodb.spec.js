/* eslint-disable arrow-body-style */
const service = require('./dynamodb.service');

describe('Service - dynamodb', () => {
  beforeEach(() => {});

  afterEach(() => {});

  it('TODO: should do unit test for ', () => {
    service();
  });
});
