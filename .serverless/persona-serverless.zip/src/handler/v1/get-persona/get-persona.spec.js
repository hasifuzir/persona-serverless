/* eslint-disable arrow-body-style */

describe('Test getPersona', () => {
  beforeEach(() => {});

  afterEach(() => {});

  it('TODO: should do unit test for getPersona', () => {
  });
});
