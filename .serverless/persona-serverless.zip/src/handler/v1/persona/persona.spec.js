/* eslint-disable arrow-body-style */

describe('Test persona', () => {
  beforeEach(() => {});

  afterEach(() => {});

  it('TODO: should do unit test for persona', () => {
  });
});
