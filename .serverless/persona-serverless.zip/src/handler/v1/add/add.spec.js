/* eslint-disable arrow-body-style */

describe('Test add', () => {
  beforeEach(() => {});

  afterEach(() => {});

  it('TODO: should do unit test for add', () => {
  });
});
