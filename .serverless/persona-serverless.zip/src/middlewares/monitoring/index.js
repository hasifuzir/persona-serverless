const { monitoringMiddleware } = require('./monitoring.middleware');

module.exports = {
  monitoringMiddleware
};
