const { routeValidator } = require('./route-validation.middleware');

module.exports = {
  routeValidator
};
